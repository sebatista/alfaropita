# FineCrop
jQuery FineCrop plugin


As this is a jQuery plugin you will find fineCrop.js from js folder also get the fineCrop.css from css folder.

# index.html
In this file you will get the strucure and explaination in commented line.

# Use of plugin
     $("#upphoto").finecrop({
        viewHeight: 500,
        cropWidth: 200,
        cropHeight: 200,
        cropInput: 'inputImage',
        cropOutput: 'croppedImg',
        zoomValue: 50
    });

* #upphoto is the id of input type file

Other explainations are in index file, when you run you will see it clearly    